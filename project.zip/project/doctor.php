<?php 
$con = mysqli_connect('localhost', 'root', '','project__1');

?>