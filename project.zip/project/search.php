<?php 
$con = mysqli_connect('localhost', 'root', '','project__1');

// get the post records
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$patient_id = $_POST['patient_id'];
$sql = "SELECT * FROM patient";

$sql = "SELECT * FROM patient where patient_id=$patient_id";

$result = mysqli_query($con, $sql);

if (!$result) {
    die("Error in SQL query: " . mysqli_error($con));
}

if($result)
{
	echo '<table border="2px">
    <tr>
        <th>Patient ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Gender</th>
        <th>Date Of Birth</th>
        <th>Contact Number</th>
        <th>Address</th>
        <th>Email</th>
    </tr>';

    $row = mysqli_fetch_assoc($result);
        echo '<tr>';
        echo'<td>'.   $row['patient_id'] . '</td>';
        echo '<td>' . $row['first_name'] . '</td>';
        echo '<td>' . $row['last_name'] . '</td>';
        echo '<td>' . $row['gender'] . '</td>';
        echo '<td>' . $row['date_of_birth'] . '</td>';
        echo '<td>' . $row['contact_number'] . '</td>';
        echo '<td>' . $row['address'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '</tr>';
    


    echo '</table>';
}
else
{
    echo "error!!";
}
?>
