<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="new.css">
</head>
<body>
    <nav class="nav-bar">
        <ul>
            <li><a href="index.html">HOME</a></li>
            <li><a href="new_patient.html">NEW PATIENT</a></li>
            <li><a href="#">LOGIN</a></li>
            <li><a href="search.html">SEARCH</a></li>
            <li><a href="appointment.html">APPOINTMENT</a></li>
            <li><a href="doctor.html">DOCTORS</a></li>
            <li><a href="about.html">ABOUT</a></li>
        </ul>
     
        <img src="med.jpg"></img> -->
    <!-- </nav>
    <p class="heading">LOGIN</p>
    <div class="info">
    <form action="login.php" method="post">
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" required><br><br>
    
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" required><br><br>

    
        <label for="patient_id">Patient ID:</label>
        <input type="text" id="patient_id" name="patient_id" required><br><br>
        
        
       <a href="index.html"><button class="btn">SUBMIT</button></a>
    </form>
</div>

<footer class="footer">
    <p>www.myhospital.com &copy; myhealth.com</p>
</footer>
</body> 
</html> -->

<!DOCTYPE html>

<html>

<head>

    <title>LOGIN</title>

    <link rel="stylesheet" type="text/css" href="new.css">

</head>

<body>
<nav class="nav-bar">
        <ul>
            <li><a href="home.html">HOME</a></li>
            <li><a href="new_patient.html">NEW PATIENT</a></li>
            <li><a href="#">LOGIN</a></li>
            <li><a href="search.html">SEARCH</a></li>
            <li><a href="appointment.html">APPOINTMENT</a></li>
            <li><a href="doctor.html">DOCTORS</a></li>
            <li><a href="about.html">ABOUT</a></li>
        </ul>
     
        <!-- <img src="med.jpg"></img>  -->
    </nav>

     <form action="login.php" method="post">

        <h2>LOGIN</h2>

        <?php if (isset($_GET['error'])) { ?>

            <p class="error"><?php echo $_GET['error']; ?></p>

        <?php } ?>

        <label>User Name</label>

        <input type="text" name="uname" placeholder="User Name"><br>

        <label>Password</label>

        <input type="password" name="password" placeholder="Password"><br> 

        <button type="submit">Login</button>
        

        <!-- <a href="signin.php"><button type="submit">NEW USER? SIGN IN</button></a> -->

     </form>

</body>

</html>